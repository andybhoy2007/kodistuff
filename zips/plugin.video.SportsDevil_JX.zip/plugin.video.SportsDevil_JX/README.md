# SportsDevil_JX
This is an unofficial SportsDevil fork by JairoX.
For information on current developmnent and maintenance status, pls check the forum.
