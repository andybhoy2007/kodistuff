# SportsDevil_JX
This is an unofficial SportsDevil clone by JairoX.
For information on current developmnent and maintenance status, pls check the forum.
