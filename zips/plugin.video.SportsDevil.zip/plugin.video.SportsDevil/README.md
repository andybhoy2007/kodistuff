# SportsDevil_JX
This is an unofficial SportsDevil clone by JairoX.
For information on current developmnent and maintenance status, see here: https://www.tvaddons.ag/forums/sportsdevil-addon-for-kodi/27329-future-sportsdevil-post-github-dmca-issue.html
